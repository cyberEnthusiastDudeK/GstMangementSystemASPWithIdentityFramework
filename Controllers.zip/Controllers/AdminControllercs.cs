﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectInfinityGST.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
