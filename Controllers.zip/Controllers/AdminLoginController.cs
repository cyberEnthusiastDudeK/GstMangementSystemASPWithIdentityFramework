﻿// Controllers/AdminController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using ProjectInfinityGST.Models; // Update with your actual namespace

public class AdminLoginController : Controller
{
    private readonly SignInManager<IdentityUser> _signInManager;

    public AdminLoginController(SignInManager<IdentityUser> signInManager)
    {
        _signInManager = signInManager;
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(AdminView model)
    {
        if (ModelState.IsValid)
        {
            var result = await _signInManager.PasswordSignInAsync(model.adm_Email, model.adm_Password, false, lockoutOnFailure: true);
            if (result.Succeeded)
            {
                return RedirectToAction("IndexAdmin", "Admin"); // Redirect to the admin dashboard
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }
        }
        return View(model);
    }

    public async Task<IActionResult> Logout()
    {
        await _signInManager.SignOutAsync();
        return RedirectToAction("Index", "Home"); // Redirect to the home page after logout
    }
}
