﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectInfinityGST.Data;
using ProjectInfinityGST.Models;
using System;

namespace ProjectInfinityGST.Controllers
{
    public class BookController : Controller
    {
        private readonly ApplicationDbContext applicationDbContext;

        public BookController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;


        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
           var b = await applicationDbContext.Clientbookings.ToListAsync();
            return View(b);    
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(BookClient bookClientRequest)
        {
            // Create a new instance of BookClient
            var bookClient = new BookClient
            {
                Id = Guid.NewGuid(),
                Name = bookClientRequest.Name,
                Email = bookClientRequest.Email,
                DateOfBooking = bookClientRequest.DateOfBooking,
                TimeSlot = bookClientRequest.TimeSlot
            };

            await applicationDbContext.Clientbookings.AddAsync(bookClient);
            await applicationDbContext.SaveChangesAsync();
            // Now you can use 'bookClient' as needed, for example, save it to a database.

            return RedirectToAction("Index"); // Redirect to some action after processing the data.
        }

    }
}
