﻿// Models/Admin.cs
using System.ComponentModel.DataAnnotations;

namespace ProjectInfinityGST.Models
{
    public class Admin
    {
        internal string adm_Password;

        public int ID { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string AdminEmail { get; set; }

        [Required]
        [Display(Name = "Password")]
        public string AdminPass { get; set; }
    }
}
