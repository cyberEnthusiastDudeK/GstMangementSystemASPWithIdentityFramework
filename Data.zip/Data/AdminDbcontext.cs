﻿// Data/ApplicationDbContext.cs
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProjectInfinityGST.Models;

namespace ProjectInfinityGST.Data
{
    public class AdminDbcontext : IdentityDbContext
    {
        public AdminDbcontext(DbContextOptions<AdminDbcontext> options)
            : base(options)
        {
        }

        public DbSet<Admin> Admins { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed initial admin data
            modelBuilder.Entity<Admin>().HasData(
                new Admin
                {
                    //Id = 1,
                    AdminEmail = "admin@example.com",
                    AdminPass = "adminpassword"
                }
            );
        }
    }
}
