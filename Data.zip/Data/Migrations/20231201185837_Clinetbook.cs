﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectInfinityGST.Data.Migrations
{
    /// <inheritdoc />
    public partial class Clinetbook : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ClientAppointmentBookings");

            migrationBuilder.CreateTable(
                name: "Clientbookings",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBooking = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TimeSlot = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientbookings", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clientbookings");

            migrationBuilder.CreateTable(
                name: "ClientAppointmentBookings",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Client_email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Client_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBooking = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TimeSlot = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientAppointmentBookings", x => x.Id);
                });
        }
    }
}
