﻿namespace ProjectInfinityGST.Models
{
    public class AdminView
    {
        public int ID { get; set; }

        public string adm_Email { get; set; }

        public string adm_Password { get; set;}
    }
}
