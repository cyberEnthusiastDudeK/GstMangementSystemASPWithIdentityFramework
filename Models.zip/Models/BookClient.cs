﻿using System.ComponentModel.DataAnnotations;

namespace ProjectInfinityGST.Models
{
    public class BookClient
    {

        [Key]
        public Guid Id { get; set; }

        [Required]
        public string Name { get; set; }
        
        [Required]

        public string Email { get; set; }

        [Required]
        public DateTime DateOfBooking { get; set; }

        [Required]
        public DateTime TimeSlot { get; set; }

       
    }
}